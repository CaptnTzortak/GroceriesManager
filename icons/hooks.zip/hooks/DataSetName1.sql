update x_MODULES set CUSTOMLABELHEADER = 
case when COALESCE(REGEXP_SUBSTR(mname,'[^.]+$'), mname) IN ('TXT','CSV') 
then COALESCE(REGEXP_SUBSTR(mname,'[^.]+\.[^.]+$'),mname) 
else COALESCE(REGEXP_SUBSTR(mname,'[^.]+$'), mname) 
end 
where mtype = 'FILE' and msubtype = 'DB' and msubtype2 = 'WORKFILE';